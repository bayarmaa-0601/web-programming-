

var calendar2021 = {
    jan: {1: "Сайхан амарна"}, 
	feb: {1: "Сагсны тэмцээнтэй", 3: "Шагнал гардуулна даа", 17: "Жавхлан багшийн лаб 2-ыг хийнэ"}, 
	mar: {2: "Энэ лабынхаа хугацааг сунгах уу яах вэ гэдэгээ шийднэ", 6: "Энд юу бичье дээ байз", 8: "Эмэгтэйчүүддээ баяр хүргэнэ дээ"}, 
	apr: {1: "Бүгдээрээ худлаа ярьцаагаагаарай"}, 
	may: {10: "Энэ сард ч ёстой юу ч болдоггүй сар даа"}, 
	jun: {6: "Жавхлан багшийн төрсөн өдөр"},  
	jul: {4: "Хичээл амарсаан ураа"}, 
	aug: {1: "Хөдөө явдаг цаг даа", 25: "Хичээл сонголт эхэллээ"}, 
	sep: {1: "9-н сарын нэгэн боллоо ерөөсөө бидний баяр даа"}, 
	oct: {13: "Сур сур бас дахин сур"}, 
	nov: {2: "Сурсаар л бай"}, 
	dec: {20: "Өвлийн семистер хаагдах нь дээ", 30: "Дүн гаргаж дууслаа баярлалаа баяртай"} 

}

	var  x;
	for(x in calendar2021.jan){
		document.getElementById("jan").innerHTML += x + "<br>";
		document.getElementById("jan1").innerHTML += calendar2021.jan[x] + "<br>";
	}
	for(x in calendar2021.feb){
		document.getElementById("feb").innerHTML = x + "<br>";
		document.getElementById("feb1").innerHTML += calendar2021.feb[x] + "<br>";
	}
	for(x in calendar2021.mar){
		document.getElementById("mar").innerHTML += x + "<br>";
		document.getElementById("mar1").innerHTML += calendar2021.mar[x] + "<br>";
	}
	for(x in calendar2021.apr){
		document.getElementById("apr").innerHTML += x + "<br>";
		document.getElementById("apr1").innerHTML += calendar2021.apr[x] + "<br>";
	}
	for(x in calendar2021.may){
		document.getElementById("may").innerHTML += x + "<br>";
		document.getElementById("may1").innerHTML += calendar2021.may[x] + "<br>";
	}
	for(x in calendar2021.jun){
		document.getElementById("jun").innerHTML += x + "<br>";
		document.getElementById("jun1").innerHTML += calendar2021.jun[x] + "<br>";
	}
	for(x in calendar2021.jul){
		document.getElementById("jul").innerHTML += x + "<br>";
		document.getElementById("jul1").innerHTML += calendar2021.jul[x] + "<br>";
	}
	for(x in calendar2021.aug){
		document.getElementById("aug").innerHTML += x + "<br>";
		document.getElementById("aug1").innerHTML += calendar2021.aug[x] + "<br>";
	}
	for(x in calendar2021.sep){
		document.getElementById("sep").innerHTML += x + "<br>";
		document.getElementById("sep1").innerHTML += calendar2021.sep[x] + "<br>";
	}
	for(x in calendar2021.oct){
		document.getElementById("oct").innerHTML += x + "<br>";
		document.getElementById("oct1").innerHTML += calendar2021.oct[x] + "<br>";
	}
	for(x in calendar2021.nov){
		document.getElementById("nov").innerHTML += x + "<br>";
		document.getElementById("nov1").innerHTML += calendar2021.nov[x] + "<br>";
	}
	for(x in calendar2021.dec){
		document.getElementById("dec").innerHTML += x + "<br>";
		document.getElementById("dec1").innerHTML += calendar2021.dec[x] + "<br>";
	}


